# 3D Streetwear Store — Architecture & Setup

## Stack
Next.js 14 (App Router) · React Three Fiber · Tailwind CSS · Node/Express API · MongoDB · JWT + bcrypt

## File Structure

```
streetwear-store/
├── apps/
│   ├── web/                         # Next.js frontend
│   │   ├── app/
│   │   │   ├── [locale]/            # en / ar route segments (next-intl)
│   │   │   │   ├── page.tsx         # Home
│   │   │   │   ├── shop/page.tsx
│   │   │   │   ├── product/[slug]/page.tsx
│   │   │   │   ├── checkout/page.tsx
│   │   │   │   └── layout.tsx       # sets dir="rtl"/"ltr"
│   │   │   └── globals.css
│   │   ├── components/
│   │   │   ├── nav/Navbar.tsx
│   │   │   ├── three/ProductViewer3D.tsx
│   │   │   ├── three/HeroScene.tsx
│   │   │   ├── shop/ProductCard.tsx
│   │   │   ├── shop/FilterPanel.tsx
│   │   │   ├── cart/CartDrawer.tsx
│   │   │   └── checkout/CheckoutModal.tsx
│   │   ├── lib/
│   │   │   ├── i18n.ts
│   │   │   ├── api.ts               # fetch wrapper, attaches CSRF header
│   │   │   └── store.ts             # zustand cart/auth store
│   │   ├── messages/
│   │   │   ├── en.json
│   │   │   └── ar.json
│   │   ├── tailwind.config.ts
│   │   └── next.config.js           # security headers here
│   │
│   └── api/                         # Express backend
│       ├── src/
│       │   ├── server.ts
│       │   ├── middleware/
│       │   │   ├── security.ts      # helmet, csp, rate limit, sanitize
│       │   │   ├── csrf.ts
│       │   │   └── auth.ts          # JWT verify
│       │   ├── routes/
│       │   │   ├── auth.routes.ts   # login/register/oauth
│       │   │   ├── products.routes.ts
│       │   │   ├── cart.routes.ts
│       │   │   └── checkout.routes.ts
│       │   ├── models/
│       │   │   ├── User.ts
│       │   │   ├── Product.ts
│       │   │   └── Order.ts
│       │   └── utils/
│       │       ├── bcrypt.ts
│       │       └── tokenize-payment.ts  # mock Stripe-style tokenization
│       └── .env.example
│
├── docker-compose.yml                # web + api + mongo
└── package.json                      # workspaces root
```

## Setup

```bash
# 1. clone/scaffold
npx create-next-app@latest apps/web --typescript --tailwind --app
mkdir apps/api && cd apps/api && npm init -y

# 2. frontend deps
cd apps/web
npm install three @react-three/fiber @react-three/drei zustand next-intl framer-motion

# 3. backend deps
cd ../api
npm install express mongoose jsonwebtoken bcrypt helmet cors \
  express-rate-limit express-mongo-sanitize xss-clean csurf cookie-parser dotenv
npm install -D typescript ts-node-dev @types/express @types/node

# 4. env vars (apps/api/.env)
MONGO_URI=mongodb://localhost:27017/streetwear
JWT_SECRET=<generate with `openssl rand -hex 32`>
JWT_EXPIRES_IN=7d
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
STRIPE_SECRET_KEY=sk_test_...
CLIENT_ORIGIN=http://localhost:3000

# 5. run
docker-compose up -d mongo
npm run dev --workspace=apps/api
npm run dev --workspace=apps/web
```

## Security checklist implemented
- [x] bcrypt (12 salt rounds) for passwords, never stored plaintext
- [x] JWT access token (short-lived) + httpOnly refresh cookie
- [x] OAuth 2.0 (Google/Apple) via passport strategies, no password path for those accounts
- [x] express-mongo-sanitize + xss-clean on all inbound bodies
- [x] csurf token issued per session, required on state-changing routes
- [x] express-rate-limit: 5 login attempts / 15 min per IP, 20 checkout attempts / hr
- [x] helmet with strict CSP (no `unsafe-inline` except hashed Three.js canvas init)
- [x] HTTPS enforced via redirect middleware + HSTS header
- [x] Payment tokenization mock — raw card data never touches your server
