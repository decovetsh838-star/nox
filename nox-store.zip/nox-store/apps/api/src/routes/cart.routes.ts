import { Router } from 'express';
import Product from '../models/Product';

const router = Router();

/** Client sends only {productId, color, size, qty} lines — price and
 *  availability are always recomputed server-side, never trusted from the client. */
router.post('/price', async (req, res) => {
  const { lines } = req.body as { lines: { productId: string; color: string; size: string; qty: number }[] };
  if (!Array.isArray(lines)) return res.status(400).json({ error: 'Invalid cart payload.' });

  let subtotal = 0;
  const priced = [];

  for (const line of lines) {
    const product = await Product.findById(line.productId);
    if (!product) continue;

    const stockKey = `${line.color}-${line.size}`;
    const available = product.stock.get(stockKey) ?? 0;
    const qty = Math.min(line.qty, available);

    subtotal += product.price * qty;
    priced.push({ productId: product.id, name: product.name, color: line.color, size: line.size, qty, price: product.price });
  }

  res.json({ lines: priced, subtotal });
});

export default router;
