import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/User';
import { authLimiter } from '../middleware/security';

const router = Router();
const SALT_ROUNDS = 12;

router.post('/register', authLimiter, async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password || password.length < 8) {
    return res.status(400).json({ error: 'Valid email and password (8+ chars) required.' });
  }

  const existing = await User.findOne({ email });
  if (existing) return res.status(409).json({ error: 'Account already exists.' });

  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
  const user = await User.create({ email, passwordHash, name });

  const token = signAccessToken(user.id);
  setRefreshCookie(res, user.id);
  res.status(201).json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

router.post('/login', authLimiter, async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });

  // Constant-shape response whether the user exists or not — avoids user enumeration
  const valid = user ? await bcrypt.compare(password, user.passwordHash) : false;
  if (!user || !valid) return res.status(401).json({ error: 'Invalid credentials.' });

  const token = signAccessToken(user.id);
  setRefreshCookie(res, user.id);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

// Google/Apple OAuth callbacks issue the same JWT shape so the frontend
// doesn't need to branch on auth method after login.
router.post('/oauth/callback', async (req, res) => {
  const { provider, providerAccountId, email, name } = req.body; // populated by passport strategy upstream
  let user = await User.findOne({ email });
  if (!user) user = await User.create({ email, name, provider, providerAccountId, passwordHash: null });

  const token = signAccessToken(user.id);
  setRefreshCookie(res, user.id);
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

function signAccessToken(userId: string) {
  return jwt.sign({ sub: userId }, process.env.JWT_SECRET!, {
    expiresIn: process.env.JWT_EXPIRES_IN ?? '15m',
  });
}

function setRefreshCookie(res: any, userId: string) {
  const refreshToken = jwt.sign({ sub: userId, type: 'refresh' }, process.env.JWT_SECRET!, { expiresIn: '30d' });
  res.cookie('refresh_token', refreshToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 30 * 24 * 60 * 60 * 1000,
  });
}

export default router;
