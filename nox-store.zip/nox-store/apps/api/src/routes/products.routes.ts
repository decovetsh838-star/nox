import { Router } from 'express';
import Product from '../models/Product';

const router = Router();

router.get('/', async (req, res) => {
  const { category, size, color, maxPrice } = req.query;
  const query: Record<string, any> = {};

  if (category) query.category = category;
  if (size) query.sizes = size;
  if (color) query.colors = color;
  if (maxPrice) query.price = { $lte: Number(maxPrice) };

  const products = await Product.find(query).limit(100);
  res.json(products);
});

router.get('/:slug', async (req, res) => {
  const product = await Product.findOne({ slug: req.params.slug });
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  res.json(product);
});

export default router;
