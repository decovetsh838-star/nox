import { Router } from 'express';
import Order from '../models/Order';
import { mockTokenizeCharge } from '../utils/tokenize-payment';

const router = Router();

router.post('/', async (req, res) => {
  const { email, address, paymentToken, amount, items } = req.body;

  if (!email || !address || !paymentToken || !amount) {
    return res.status(400).json({ error: 'Missing required checkout fields.' });
  }

  // Real integration: call Stripe/PayPal's charge API with paymentToken here.
  // The server never sees raw card details — only this opaque token.
  const charge = await mockTokenizeCharge({ token: paymentToken, amount });
  if (!charge.success) return res.status(402).json({ error: 'Payment declined.' });

  const order = await Order.create({
    email,
    address,
    items: items ?? [],
    total: amount,
    paymentTokenRef: charge.chargeId,
    status: 'paid',
  });

  res.status(201).json({ orderId: order.id, status: order.status });
});

export default router;
