/**
 * Mock payment tokenization — stands in for the Stripe/PayPal SDK call.
 * Real card data NEVER reaches this server: in production, Stripe.js/Elements
 * tokenizes the card in the browser and this function calls
 * `stripe.charges.create({ source: token, amount })` with the resulting token.
 */
export async function mockTokenizeCharge({ token, amount }: { token: string; amount: number }) {
  const isValidMockToken = token.startsWith('tok_');
  await new Promise((r) => setTimeout(r, 400)); // simulate gateway latency

  if (!isValidMockToken || amount <= 0) {
    return { success: false, chargeId: null };
  }

  return { success: true, chargeId: `ch_mock_${Date.now()}` };
}
