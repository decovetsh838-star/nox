import express from 'express';
import mongoose from 'mongoose';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import { applyCoreSecurity, csrfProtection, csrfErrorHandler, checkoutLimiter } from './middleware/security';
import authRoutes from './routes/auth.routes';
import productRoutes from './routes/products.routes';
import cartRoutes from './routes/cart.routes';
import checkoutRoutes from './routes/checkout.routes';

dotenv.config();

const app = express();

app.use(express.json({ limit: '100kb' })); // caps body size — cheap DoS guard
app.use(cookieParser());
applyCoreSecurity(app);

// Frontend fetches this once on load, sends it back as X-CSRF-Token on writes
app.get('/api/csrf-token', csrfProtection, (req, res) => {
  res.json({ csrfToken: req.csrfToken() });
});

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes); // read-only, no CSRF needed
app.use('/api/cart', csrfProtection, cartRoutes);
app.use('/api/checkout', csrfProtection, checkoutLimiter, checkoutRoutes);

app.use(csrfErrorHandler);

const PORT = process.env.PORT ?? 4000;

mongoose
  .connect(process.env.MONGO_URI!)
  .then(() => {
    app.listen(PORT, () => console.log(`NOX API running on :${PORT}`));
  })
  .catch((err) => {
    console.error('Mongo connection failed:', err.message);
    process.exit(1);
  });
