import { Schema, model } from 'mongoose';

const ProductSchema = new Schema(
  {
    name: { en: String, ar: String },
    slug: { type: String, required: true, unique: true },
    category: { type: String, required: true },
    price: { type: Number, required: true, min: 0 },
    currency: { type: String, default: 'USD' },
    image: String,
    gallery: [String],
    colors: [String],
    sizes: [String],
    stock: { type: Map, of: Number, default: {} }, // key: `${color}-${size}`
    isNew: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export default model('Product', ProductSchema);
