import { Schema, model } from 'mongoose';

const OrderSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: false }, // guest checkout allowed
    email: { type: String, required: true },
    address: { type: String, required: true },
    items: [
      {
        productId: { type: Schema.Types.ObjectId, ref: 'Product' },
        name: String,
        color: String,
        size: String,
        qty: Number,
        price: Number,
      },
    ],
    total: { type: Number, required: true },
    paymentTokenRef: { type: String, required: true }, // reference to gateway charge, never raw card data
    status: { type: String, enum: ['pending', 'paid', 'failed', 'shipped'], default: 'pending' },
  },
  { timestamps: true }
);

export default model('Order', OrderSchema);
