import { Schema, model } from 'mongoose';

const UserSchema = new Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, default: null }, // null for OAuth-only accounts
    name: { type: String, required: true, trim: true },
    provider: { type: String, enum: ['local', 'google', 'apple'], default: 'local' },
    providerAccountId: { type: String, default: null },
  },
  { timestamps: true }
);

export default model('User', UserSchema);
