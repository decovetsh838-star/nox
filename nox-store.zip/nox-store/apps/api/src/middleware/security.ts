import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';
import mongoSanitize from 'express-mongo-sanitize';
import xssClean from 'xss-clean';
import csrf from 'csurf';
import type { Express, Request, Response, NextFunction } from 'express';

const ORIGIN = process.env.CLIENT_ORIGIN ?? 'http://localhost:3000';

/** Strict CSP — only same-origin scripts, no inline except our hashed inline bootstrap */
const cspDirectives = {
  defaultSrc: ["'self'"],
  scriptSrc: ["'self'"],
  styleSrc: ["'self'", "'unsafe-inline'"], // Tailwind injects style tags at build, not runtime user input
  imgSrc: ["'self'", 'data:', 'blob:', 'https://res.cloudinary.com'],
  connectSrc: ["'self'", ORIGIN, 'https://api.stripe.com'],
  frameSrc: ["https://js.stripe.com"],
  objectSrc: ["'none'"],
  baseUri: ["'self'"],
  frameAncestors: ["'none'"],
  upgradeInsecureRequests: [],
};

export function applyCoreSecurity(app: Express) {
  app.set('trust proxy', 1); // needed for correct IP behind a reverse proxy (rate limiting)

  app.use(helmet({ contentSecurityPolicy: { directives: cspDirectives } }));
  app.use(helmet.hsts({ maxAge: 31536000, includeSubDomains: true, preload: true }));

  app.use(cors({ origin: ORIGIN, credentials: true }));

  // Redirect any stray HTTP request to HTTPS in production
  app.use((req: Request, res: Response, next: NextFunction) => {
    if (process.env.NODE_ENV === 'production' && req.headers['x-forwarded-proto'] !== 'https') {
      return res.redirect(301, `https://${req.headers.host}${req.url}`);
    }
    next();
  });

  app.use(mongoSanitize()); // strips $ and . operators from req.body/query/params
  app.use(xssClean());      // escapes reflected HTML/script in inputs
}

/** Auth-specific limiter: brute-force protection on login/register */
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in 15 minutes.' },
});

/** Looser limiter for checkout, still enough to block scripted abuse */
export const checkoutLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 20,
  message: { error: 'Too many checkout attempts. Please slow down.' },
});

/** CSRF protection using a double-submit cookie; frontend reads the token
 *  from GET /api/csrf-token and sends it back as X-CSRF-Token on writes. */
export const csrfProtection = csrf({
  cookie: { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production' },
});

export function csrfErrorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  if (err.code !== 'EBADCSRFTOKEN') return next(err);
  res.status(403).json({ error: 'Invalid or missing CSRF token.' });
}
