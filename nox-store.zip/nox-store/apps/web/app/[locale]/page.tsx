import { useTranslations } from 'next-intl';
import HeroScene from '@/components/three/HeroScene';

export default function HomePage() {
  const t = useTranslations('hero');

  return (
    <section className="relative min-h-[calc(100vh-6rem)] flex flex-col md:flex-row items-center px-6 md:px-16 gap-10">
      <div className="flex-1 max-w-xl z-10">
        <p className="text-sage text-sm tracking-widest uppercase mb-4">{t('eyebrow')}</p>
        <h1 className="text-4xl md:text-6xl font-medium leading-[1.05] mb-6">{t('headline')}</h1>
        <p className="text-cream/70 text-lg mb-8">{t('subhead')}</p>
        <a
          href="./shop"
          className="inline-block bg-sage text-charcoal font-medium px-8 py-3.5 rounded-lg hover:brightness-110 transition"
        >
          {t('cta')}
        </a>
      </div>

      <div className="flex-1 w-full">
        <HeroScene />
      </div>
    </section>
  );
}
