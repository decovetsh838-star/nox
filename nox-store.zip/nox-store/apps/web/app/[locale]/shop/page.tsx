'use client';

import { useMemo, useState } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import FilterPanel, { FilterState } from '@/components/shop/FilterPanel';
import ProductCard from '@/components/shop/ProductCard';
import { PRODUCTS } from '@/lib/products'; // static seed data — swap for an API fetch when the backend is live

const DEFAULT_FILTERS: FilterState = { categories: [], sizes: [], colors: [], priceRange: [0, 400] };

export default function ShopPage() {
  const t = useTranslations('shop');
  const locale = useLocale() as 'en' | 'ar';
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);

  const filtered = useMemo(() => {
    return PRODUCTS.filter((p) => {
      if (filters.categories.length && !filters.categories.includes(p.category)) return false;
      if (filters.sizes.length && !p.sizes.some((s) => filters.sizes.includes(s))) return false;
      if (filters.colors.length && !p.colors.some((c) => filters.colors.includes(c))) return false;
      if (p.price > filters.priceRange[1]) return false;
      return true;
    });
  }, [filters]);

  return (
    <section className="px-6 md:px-16 py-10 flex flex-col md:flex-row gap-10">
      <FilterPanel filters={filters} onChange={setFilters} />

      <div className="flex-1">
        {filtered.length === 0 ? (
          <p className="text-cream/50 text-center py-20">{t('noResults')}</p>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-5">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} locale={locale} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
