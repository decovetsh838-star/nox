import { NextIntlClientProvider } from 'next-intl';
import { getMessages } from 'next-intl/server';
import { locales } from '@/lib/i18n';
import Navbar from '@/components/nav/Navbar';
import CartDrawer from '@/components/cart/CartDrawer';
import '../globals.css';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({
  children,
  params: { locale },
}: {
  children: React.ReactNode;
  params: { locale: string };
}) {
  const messages = await getMessages();
  const dir = locale === 'ar' ? 'rtl' : 'ltr';

  return (
    <html lang={locale} dir={dir}>
      <body className="bg-charcoal text-cream font-sans antialiased">
        <NextIntlClientProvider messages={messages}>
          <Navbar />
          <main className="pt-24">{children}</main>
          <CartDrawer />
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
