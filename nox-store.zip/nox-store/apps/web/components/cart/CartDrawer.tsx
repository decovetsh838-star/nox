'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { useTranslations, useLocale } from 'next-intl';
import { useCartStore } from '@/lib/store';

const SHIPPING_FLAT = 5;
const FREE_SHIPPING_THRESHOLD = 100;

export default function CartDrawer() {
  const t = useTranslations('cart');
  const locale = useLocale();
  const { items, isOpen, closeDrawer, updateQty, removeItem } = useCartStore();

  const subtotal = items.reduce((sum, i) => sum + i.price * i.qty, 0);
  const shipping = subtotal === 0 || subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : SHIPPING_FLAT;
  const total = subtotal + shipping;

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeDrawer}
            className="fixed inset-0 bg-charcoal/60 backdrop-blur-sm z-40"
          />
          <motion.aside
            initial={{ x: locale === 'ar' ? '-100%' : '100%' }}
            animate={{ x: 0 }}
            exit={{ x: locale === 'ar' ? '-100%' : '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 32 }}
            className="fixed inset-y-0 end-0 z-50 w-full max-w-md bg-charcoal border-s border-slate/40 flex flex-col"
          >
            <header className="flex items-center justify-between px-6 py-5 border-b border-slate/40">
              <h2 className="text-cream font-medium">{t('title')} ({items.length})</h2>
              <button onClick={closeDrawer} aria-label={t('close')} className="text-cream/60 hover:text-cream">✕</button>
            </header>

            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
              {items.length === 0 && <p className="text-cream/50 text-sm pt-8 text-center">{t('empty')}</p>}
              {items.map((item) => (
                <div key={`${item.id}-${item.color}-${item.size}`} className="flex gap-4">
                  <img src={item.image} alt={item.name[locale]} className="w-20 h-24 object-cover rounded-lg" />
                  <div className="flex-1">
                    <p className="text-cream text-sm">{item.name[locale]}</p>
                    <p className="text-cream/50 text-xs mt-0.5">{item.size} · {item.color}</p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center gap-2">
                        <button onClick={() => updateQty(item.id, item.color, item.size, Math.max(1, item.qty - 1))} className="w-6 h-6 rounded border border-slate/60 text-cream/70">−</button>
                        <span className="text-cream text-sm w-4 text-center">{item.qty}</span>
                        <button onClick={() => updateQty(item.id, item.color, item.size, item.qty + 1)} className="w-6 h-6 rounded border border-slate/60 text-cream/70">+</button>
                      </div>
                      <p className="text-cream text-sm">{item.price * item.qty} {item.currency}</p>
                    </div>
                  </div>
                  <button onClick={() => removeItem(item.id, item.color, item.size)} className="text-cream/40 hover:text-cream/80 text-xs self-start">{t('remove')}</button>
                </div>
              ))}
            </div>

            {items.length > 0 && (
              <footer className="border-t border-slate/40 px-6 py-5 space-y-2">
                <Row label={t('subtotal')} value={subtotal} />
                <Row label={shipping === 0 ? t('freeShipping') : t('shipping')} value={shipping} />
                <Row label={t('total')} value={total} bold />
                <a href={`/${locale}/checkout`} className="block text-center bg-sage text-charcoal font-medium py-3 rounded-lg mt-4">
                  {t('checkout')}
                </a>
              </footer>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}

function Row({ label, value, bold }: { label: string; value: number; bold?: boolean }) {
  return (
    <div className={`flex justify-between text-sm ${bold ? 'text-cream font-medium text-base pt-2' : 'text-cream/60'}`}>
      <span>{label}</span>
      <span>{value === 0 ? '—' : value}</span>
    </div>
  );
}
