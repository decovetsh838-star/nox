'use client';

import { useState, useEffect } from 'react';
import { useLocale, useTranslations } from 'next-intl';
import { usePathname, useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { useCartStore } from '@/lib/store';

const LOCALES = [
  { code: 'en', label: 'EN', dir: 'ltr' },
  { code: 'ar', label: 'AR', dir: 'rtl' },
] as const;

export default function Navbar() {
  const t = useTranslations('nav');
  const locale = useLocale();
  const pathname = usePathname();
  const router = useRouter();
  const [scrolled, setScrolled] = useState(false);
  const cartCount = useCartStore((s) => s.items.length);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Swap locale segment, preserve the rest of the path, flip <html dir>
  const switchLocale = (next: string) => {
    const segments = pathname.split('/');
    segments[1] = next;
    const targetDir = LOCALES.find((l) => l.code === next)?.dir ?? 'ltr';
    document.documentElement.dir = targetDir;
    document.documentElement.lang = next;
    router.push(segments.join('/'));
  };

  return (
    <motion.nav
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      transition={{ type: 'spring', stiffness: 120, damping: 18 }}
      className={`fixed inset-x-0 top-0 z-50 flex items-center justify-between px-6 md:px-12 transition-[height,background-color,backdrop-filter] duration-300
        ${scrolled ? 'h-16 bg-charcoal/80 backdrop-blur-md' : 'h-24 bg-transparent'}`}
    >
      <a href={`/${locale}`} className="text-cream text-xl tracking-tight font-medium">
        {t('brandMark')}
      </a>

      <ul className="hidden md:flex items-center gap-10 text-sm text-cream/80 rtl:flex-row-reverse">
        <li><a href={`/${locale}/shop`} className="hover:text-sage transition-colors">{t('shop')}</a></li>
        <li><a href={`/${locale}/shop?new=true`} className="hover:text-sage transition-colors">{t('newArrivals')}</a></li>
        <li><a href={`/${locale}/about`} className="hover:text-sage transition-colors">{t('about')}</a></li>
      </ul>

      <div className="flex items-center gap-5">
        {/* Language toggle — real switch, not a dropdown, since there are only two states */}
        <button
          role="switch"
          aria-checked={locale === 'ar'}
          onClick={() => switchLocale(locale === 'en' ? 'ar' : 'en')}
          className="relative w-14 h-7 rounded-full bg-slate/60 flex items-center px-1"
        >
          <motion.span
            layout
            transition={{ type: 'spring', stiffness: 400, damping: 30 }}
            className="w-5 h-5 rounded-full bg-sage flex items-center justify-center text-[10px] font-semibold text-charcoal"
            style={{ marginInlineStart: locale === 'ar' ? 'auto' : 0 }}
          >
            {locale === 'en' ? 'EN' : 'AR'}
          </motion.span>
        </button>

        <button
          onClick={() => useCartStore.getState().openDrawer()}
          className="relative text-cream"
          aria-label={t('cart')}
        >
          <CartIcon />
          {cartCount > 0 && (
            <span className="absolute -top-2 -end-2 w-4 h-4 rounded-full bg-gold text-[10px] flex items-center justify-center text-charcoal font-semibold">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </motion.nav>
  );
}

function CartIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
      <path d="M6 6h15l-1.5 9h-12z" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="9" cy="20" r="1" /><circle cx="18" cy="20" r="1" />
      <path d="M6 6 5 3H2" strokeLinecap="round" />
    </svg>
  );
}
