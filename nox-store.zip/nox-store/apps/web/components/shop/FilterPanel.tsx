'use client';

import { useTranslations } from 'next-intl';

export interface FilterState {
  categories: string[];
  sizes: string[];
  colors: string[];
  priceRange: [number, number];
}

const CATEGORIES = ['hoodies', 'tees', 'outerwear', 'pants', 'accessories'];
const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL'];
const COLORS = [
  { hex: '#121212', label: 'charcoal' },
  { hex: '#9CAF88', label: 'sage' },
  { hex: '#F5F5F7', label: 'cream' },
  { hex: '#2A2C2E', label: 'slate' },
];
const MAX_PRICE = 400;

export default function FilterPanel({
  filters,
  onChange,
}: {
  filters: FilterState;
  onChange: (next: FilterState) => void;
}) {
  const t = useTranslations('filters');

  const toggle = (key: 'categories' | 'sizes' | 'colors', value: string) => {
    const set = new Set(filters[key]);
    set.has(value) ? set.delete(value) : set.add(value);
    onChange({ ...filters, [key]: Array.from(set) });
  };

  return (
    <aside className="w-full md:w-64 shrink-0 space-y-8">
      <FilterGroup title={t('category')}>
        {CATEGORIES.map((c) => (
          <Checkbox key={c} label={t(`categories.${c}`)} checked={filters.categories.includes(c)} onChange={() => toggle('categories', c)} />
        ))}
      </FilterGroup>

      <FilterGroup title={t('size')}>
        <div className="flex flex-wrap gap-2">
          {SIZES.map((s) => (
            <button
              key={s}
              onClick={() => toggle('sizes', s)}
              className={`w-10 h-10 rounded-md text-xs border transition-colors ${
                filters.sizes.includes(s)
                  ? 'border-sage bg-sage/10 text-sage'
                  : 'border-slate/60 text-cream/70 hover:border-cream/40'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title={t('color')}>
        <div className="flex gap-3">
          {COLORS.map(({ hex, label }) => (
            <button
              key={hex}
              aria-label={label}
              onClick={() => toggle('colors', hex)}
              className={`w-7 h-7 rounded-full border-2 transition-transform ${
                filters.colors.includes(hex) ? 'scale-110 border-cream' : 'border-transparent'
              }`}
              style={{ backgroundColor: hex }}
            />
          ))}
        </div>
      </FilterGroup>

      <FilterGroup title={t('price')}>
        <input
          type="range"
          min={0}
          max={MAX_PRICE}
          value={filters.priceRange[1]}
          onChange={(e) => onChange({ ...filters, priceRange: [0, Number(e.target.value)] })}
          className="w-full accent-sage"
        />
        <p className="text-cream/60 text-xs mt-1">
          {t('upTo')} {filters.priceRange[1]} {t('currency')}
        </p>
      </FilterGroup>
    </aside>
  );
}

function FilterGroup({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h4 className="text-cream text-sm font-medium mb-3">{title}</h4>
      {children}
    </div>
  );
}

function Checkbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: () => void }) {
  return (
    <label className="flex items-center gap-2.5 text-sm text-cream/70 py-1 cursor-pointer">
      <input type="checkbox" checked={checked} onChange={onChange} className="accent-sage w-4 h-4" />
      {label}
    </label>
  );
}
