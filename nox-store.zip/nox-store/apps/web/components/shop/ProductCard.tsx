'use client';

import { useRef, useState } from 'react';
import Image from 'next/image';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { useTranslations } from 'next-intl';
import { useCartStore } from '@/lib/store';

interface Product {
  id: string;
  name: { en: string; ar: string };
  price: number;
  currency: string;
  image: string;
  colors: string[];
  sizes: string[];
  isNew?: boolean;
}

export default function ProductCard({ product, locale }: { product: Product; locale: 'en' | 'ar' }) {
  const t = useTranslations('shop');
  const cardRef = useRef<HTMLDivElement>(null);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);

  // Tilt tracks pointer position, springs back to flat on leave
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [8, -8]), { stiffness: 200, damping: 20 });
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-8, 8]), { stiffness: 200, damping: 20 });

  const handlePointerMove = (e: React.PointerEvent) => {
    const rect = cardRef.current?.getBoundingClientRect();
    if (!rect) return;
    x.set((e.clientX - rect.left) / rect.width - 0.5);
    y.set((e.clientY - rect.top) / rect.height - 0.5);
  };
  const handlePointerLeave = () => { x.set(0); y.set(0); };

  return (
    <motion.div
      ref={cardRef}
      onPointerMove={handlePointerMove}
      onPointerLeave={handlePointerLeave}
      style={{ rotateX, rotateY, transformPerspective: 800 }}
      className="group relative rounded-xl overflow-hidden bg-slate/40"
    >
      {product.isNew && (
        <span className="absolute top-3 start-3 z-10 px-2.5 py-1 rounded-full bg-gold text-charcoal text-xs font-medium">
          {t('new')}
        </span>
      )}

      <div className="relative aspect-[3/4] overflow-hidden">
        <Image
          src={product.image}
          alt={product.name[locale]}
          fill
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>

      <div className="p-4 flex items-start justify-between gap-3">
        <div>
          <h3 className="text-cream text-sm font-medium">{product.name[locale]}</h3>
          <p className="text-cream/60 text-sm mt-1">
            {product.price} {product.currency}
          </p>
        </div>

        <div className="flex gap-1.5 pt-1">
          {product.colors.map((c) => (
            <button
              key={c}
              onClick={() => setSelectedColor(c)}
              aria-label={c}
              className={`w-4 h-4 rounded-full border transition-transform ${
                selectedColor === c ? 'scale-110 border-cream' : 'border-transparent'
              }`}
              style={{ backgroundColor: c }}
            />
          ))}
        </div>
      </div>

      <button
        onClick={() =>
          useCartStore.getState().addItem({ ...product, color: selectedColor, size: product.sizes[0], qty: 1 })
        }
        className="absolute inset-x-4 bottom-4 translate-y-12 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300 bg-sage text-charcoal text-sm font-medium py-2.5 rounded-lg"
      >
        {t('addToCart')}
      </button>
    </motion.div>
  );
}
