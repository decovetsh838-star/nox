'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslations } from 'next-intl';
import { useCartStore } from '@/lib/store';

type Step = 'form' | 'processing' | 'confirmed';

export default function CheckoutModal({ onClose }: { onClose: () => void }) {
  const t = useTranslations('checkout');
  const { items, clear } = useCartStore();
  const [step, setStep] = useState<Step>('form');
  const total = items.reduce((sum, i) => sum + i.price * i.qty, 0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');

    // Card fields never leave the browser as raw PAN — a real integration
    // tokenizes client-side via Stripe.js/Elements and sends only the token here.
    const form = new FormData(e.target as HTMLFormElement);
    const payload = {
      email: form.get('email'),
      address: form.get('address'),
      paymentToken: 'tok_mock_' + crypto.randomUUID(), // stand-in for Stripe.js token
      amount: total,
    };

    const csrfRes = await fetch('/api/csrf-token');
    const { csrfToken } = await csrfRes.json();

    const res = await fetch('/api/checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
      credentials: 'include',
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      clear();
      setStep('confirmed');
    } else {
      setStep('form'); // real app: surface the error message from res.json()
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-charcoal/70 backdrop-blur-sm px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-slate/95 rounded-2xl w-full max-w-md p-6"
      >
        <AnimatePresence mode="wait">
          {step === 'confirmed' ? (
            <motion.div key="confirmed" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-6">
              <h3 className="text-cream text-lg font-medium mb-2">{t('orderConfirmed')}</h3>
              <p className="text-cream/60 text-sm mb-6">{t('orderConfirmedBody')}</p>
              <button onClick={onClose} className="bg-sage text-charcoal px-6 py-2.5 rounded-lg font-medium">
                {t('close')}
              </button>
            </motion.div>
          ) : (
            <motion.form key="form" onSubmit={handleSubmit} className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-cream text-lg font-medium">{t('title')}</h3>
                <button type="button" onClick={onClose} className="text-cream/50">✕</button>
              </div>

              <Field name="email" type="email" label={t('contact')} required />
              <Field name="address" label={t('shippingAddress')} required />

              <div className="pt-2 border-t border-cream/10">
                <p className="text-cream/50 text-xs mb-3">{t('payment')}</p>
                {/* In production these three inputs are replaced by Stripe Elements
                    iframes so card data never touches this form/DOM at all. */}
                <Field name="cardNumber" label={t('cardNumber')} placeholder="4242 4242 4242 4242" required />
                <div className="flex gap-3 mt-3">
                  <Field name="expiry" label={t('expiry')} placeholder="MM/YY" required />
                  <Field name="cvc" label={t('cvc')} placeholder="123" required />
                </div>
              </div>

              <button
                type="submit"
                disabled={step === 'processing'}
                className="w-full bg-sage text-charcoal font-medium py-3 rounded-lg mt-2 disabled:opacity-60"
              >
                {step === 'processing' ? t('processing') : `${t('placeOrder')} — ${total} USD`}
              </button>
            </motion.form>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function Field({ name, label, type = 'text', placeholder, required }: any) {
  return (
    <label className="block flex-1">
      <span className="text-cream/60 text-xs">{label}</span>
      <input
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        className="w-full mt-1 bg-charcoal border border-cream/10 rounded-lg px-3 py-2.5 text-cream text-sm focus:outline-none focus:border-sage"
      />
    </label>
  );
}
