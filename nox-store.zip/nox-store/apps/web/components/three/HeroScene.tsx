'use client';

import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, Float, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';

/** Placeholder geometry standing in for a real garment .glb until one is supplied.
 *  Swap this component's body for <Garment /> from ProductViewer3D once assets land. */
function PlaceholderGarment() {
  const mesh = useRef<THREE.Mesh>(null);
  useFrame((_, delta) => {
    if (mesh.current) mesh.current.rotation.y += delta * 0.2;
  });

  return (
    <Float speed={1.4} rotationIntensity={0.4} floatIntensity={0.8}>
      <RoundedBox ref={mesh} args={[1.6, 2, 0.4]} radius={0.15} smoothness={4}>
        <meshStandardMaterial color="#9CAF88" roughness={0.4} metalness={0.1} />
      </RoundedBox>
    </Float>
  );
}

export default function HeroScene() {
  return (
    <div className="w-full h-[380px] md:h-[520px]">
      <Canvas camera={{ position: [0, 0, 5], fov: 40 }} dpr={[1, 2]}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[3, 4, 2]} intensity={1} />
        <Suspense fallback={null}>
          <PlaceholderGarment />
          <Environment preset="night" />
        </Suspense>
      </Canvas>
    </div>
  );
}
