'use client';

import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { useGLTF, Environment, ContactShadows, PresentationControls } from '@react-three/drei';
import * as THREE from 'three';

interface ProductViewer3DProps {
  modelUrl: string;       // .glb garment model
  accentColor?: string;   // maps to a material uniform for color variants
}

function Garment({ modelUrl, accentColor }: { modelUrl: string; accentColor: string }) {
  const { scene } = useGLTF(modelUrl);
  const ref = useRef<THREE.Group>(null);

  // Gentle idle rotation — the "floating" feel from the brief, paused on user drag
  useFrame((_, delta) => {
    if (ref.current) ref.current.rotation.y += delta * 0.15;
  });

  scene.traverse((child) => {
    if ((child as THREE.Mesh).isMesh) {
      const mesh = child as THREE.Mesh;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (mat?.name === 'Fabric') mat.color = new THREE.Color(accentColor);
    }
  });

  return <primitive ref={ref} object={scene} scale={1.4} />;
}

export default function ProductViewer3D({ modelUrl, accentColor = '#9CAF88' }: ProductViewer3DProps) {
  return (
    <div className="w-full h-[420px] md:h-[560px] rounded-2xl overflow-hidden bg-gradient-to-b from-charcoal to-slate">
      <Canvas
        shadows
        camera={{ position: [0, 0.4, 3.2], fov: 35 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[3, 5, 2]} intensity={1.2} castShadow />

        <Suspense fallback={null}>
          <PresentationControls
            global
            rotation={[0, 0.2, 0]}
            polar={[-0.2, 0.3]}
            azimuth={[-1, 1]}
            config={{ mass: 1, tension: 170, friction: 26 }}
          >
            <Garment modelUrl={modelUrl} accentColor={accentColor} />
          </PresentationControls>
          <Environment preset="city" />
          <ContactShadows position={[0, -1.1, 0]} opacity={0.4} scale={8} blur={2.5} />
        </Suspense>
      </Canvas>
    </div>
  );
}

// Preload common models to avoid pop-in on the product grid → detail transition
useGLTF.preload('/models/hoodie-base.glb');
