import { create } from 'zustand';

interface CartItem {
  id: string;
  name: { en: string; ar: string };
  price: number;
  currency: string;
  image: string;
  color: string;
  size: string;
  qty: number;
}

interface CartState {
  items: CartItem[];
  isOpen: boolean;
  openDrawer: () => void;
  closeDrawer: () => void;
  addItem: (item: CartItem) => void;
  updateQty: (id: string, color: string, size: string, qty: number) => void;
  removeItem: (id: string, color: string, size: string) => void;
  clear: () => void;
}

const sameLine = (a: CartItem, id: string, color: string, size: string) =>
  a.id === id && a.color === color && a.size === size;

export const useCartStore = create<CartState>((set) => ({
  items: [],
  isOpen: false,
  openDrawer: () => set({ isOpen: true }),
  closeDrawer: () => set({ isOpen: false }),

  addItem: (item) =>
    set((state) => {
      const existing = state.items.find((i) => sameLine(i, item.id, item.color, item.size));
      const items = existing
        ? state.items.map((i) => (sameLine(i, item.id, item.color, item.size) ? { ...i, qty: i.qty + item.qty } : i))
        : [...state.items, item];
      return { items, isOpen: true };
    }),

  updateQty: (id, color, size, qty) =>
    set((state) => ({
      items: state.items.map((i) => (sameLine(i, id, color, size) ? { ...i, qty } : i)),
    })),

  removeItem: (id, color, size) =>
    set((state) => ({ items: state.items.filter((i) => !sameLine(i, id, color, size)) })),

  clear: () => set({ items: [] }),
}));
