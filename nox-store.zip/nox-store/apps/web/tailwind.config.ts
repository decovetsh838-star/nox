import type { Config } from 'tailwindcss';

export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        charcoal: '#121212',
        cream: '#F5F5F7',
        slate: '#2A2C2E',
        sage: '#9CAF88',
        gold: '#D4AF37',
      },
      fontFamily: {
        sans: ['Inter', 'Tajawal', 'sans-serif'],
      },
    },
  },
  plugins: [],
} satisfies Config;
